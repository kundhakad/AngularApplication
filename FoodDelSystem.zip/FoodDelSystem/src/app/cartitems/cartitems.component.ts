import { Component, OnInit } from '@angular/core';

export class todos{
  constructor(
      public id: number,
      public name:String
    ){
  
    }
  }

  
  
@Component({
  selector: 'app-cartitems',
  templateUrl: './cartitems.component.html',
  styleUrls: ['./cartitems.component.css']
})
export class CartitemsComponent implements OnInit {

  todoArray: todos[] = [
    { id: 11, name: 'Dr Nice' },
    { id: 12, name: 'Narco' },
    { id: 13, name: 'Bombasto' },
    { id: 14, name: 'Celeritas' },
    { id: 15, name: 'Magneta' },
    { id: 16, name: 'RubberMan' },
    { id: 17, name: 'Dynama' },
    { id: 18, name: 'Dr IQ' },
    // { id: 19, name: 'Magma' },
    // { id: 20, name: 'Tornado' },
    // { id: 11, name: 'Dr Nice' },
    // { id: 12, name: 'Narco' },
    // { id: 13, name: 'Bombasto' },
    // { id: 14, name: 'Celeritas' },
    // { id: 15, name: 'Magneta' },
    // { id: 16, name: 'RubberMan' },
    // { id: 17, name: 'Dynama' },
    // { id: 18, name: 'Dr IQ' },
    // { id: 19, name: 'Magma' },
    // { id: 20, name: 'Tornado' },
    
    
  ];
  constructor() { }

  ngOnInit() {
  }

}
