import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { CustomerData } from './registration/registration.component';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {

  constructor(private http:HttpClient) { }

    saveCustomer(user :CustomerData){
      return this.http.post(`http://localhost:8080//api/customers/addCustomer`,user);
    }
  // saveCustomer(){
  //   return this.service.get<todos[]>('http://localhost:8081/users/todos');
  // }
  // createCustomer(customer: Object): Observable<Object> {
  //   return this.service.post(`${this.baseUrl}` + `/create`, customer);
  // }
}
