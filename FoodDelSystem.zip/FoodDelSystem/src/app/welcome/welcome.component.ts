import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-welcome',
  templateUrl: './welcome.component.html',
  styleUrls: ['./welcome.component.css']
})
export class WelcomeComponent implements OnInit {
  public show:boolean = false;
  public buttonName:any = 'Login';

  constructor(private router: Router) { }

  ngOnInit() {
  }
  toggle() {
    this.show = !this.show;

    // CHANGE THE NAME OF THE BUTTON.
    if(this.show)  
      this.buttonName = "Logout";
    else
      this.buttonName = "Login";
  }

  contactUs(){
//     console.log("contact us");
// this.router.navigate(['contact-us']);

  }
}
