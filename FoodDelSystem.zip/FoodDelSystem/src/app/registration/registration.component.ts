import { CustomerService } from './../customer.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {

  data:CustomerData  = new CustomerData();

  constructor(private service :CustomerService) { }

  ngOnInit() {
  }
  registerUser(){
    console.log(" Data avaliable is "+JSON.stringify(this.data));
    this.service.saveCustomer(this.data);
  }
}

export class CustomerData{
  firstName:String;
  lastName:String;
  customerPhone:String;
  customerEmail:String;
  password:String;
  address:String;
}