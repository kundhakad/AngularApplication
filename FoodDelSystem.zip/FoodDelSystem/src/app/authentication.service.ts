import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {

  constructor() { }
  authenticate(username,password){
    if (username==='vaibhav' && password ==='12345'){
     return true;
     }
     return false;
    }
    isloggeduser(){
   let user  = sessionStorage.getItem("Authuser");
   return!(user==null)
    }
}
