import { Component, OnInit } from '@angular/core';
import { AlertsService } from 'angular-alert-module';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})
export class MenuComponent implements OnInit {

  itemArray: items[] = [
    { itemId: 1, itemname: 'Mexican EggRolls',itemPrice:200},
    { itemId: 2, itemname: 'Chicken Burger',itemPrice:200},
    { itemId: 3, itemname: 'Topu Lasange',itemPrice:150},
    { itemId: 4, itemname: 'Pepper Potatoas',itemPrice:150},
    { itemId: 5, itemname: 'Bean Salad',itemPrice:120},
    { itemId: 6, itemname: 'Beatball Hoagie',itemPrice:150},
  ];

  constructor(private alert:AlertsService) { }

  ngOnInit() {
    this.alert.setMessage('Please Scroll Down To See Menus','Warn');
  }

}

export class items{
  itemId:number;
  itemname:String;
  itemPrice:number;
}
