import { Component, OnInit, Input } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { AuthenticationService } from '../authentication.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  public show:boolean = false;
  public buttonName:any = 'Login';
  username = '';
  password= '12345'
  errorMessage: boolean;
  votes:number;  
  num1:number;
  num2:number;
  result:number;
  //public username:any;
  constructor(private route:Router,private authenticateService:AuthenticationService,private actroute:ActivatedRoute) { }

  ngOnInit() {
  }
submit(uname:string){
console.log("Clicked here");
if (uname==='vinod')  //&& this.password ==='12345'
  {
  this.username = uname;
  console.log(uname);
  sessionStorage.setItem("Authuser",this.username);
  this.route.navigate(['menu']);
}else{
  console.log("Cannot logged in")
  this.errorMessage = false;
}  

  //if (this.authenticateService.authenticate(this.username,this.password)) {
//     this.errorMessage=true;
  
  
  //sessionStorage.getItem("Authuser");
  
  //name = this.uname;
  //this.username =this.actroute.snapshot.params ['username'];
}
}
