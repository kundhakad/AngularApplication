import { HeaderComponent } from './header/header.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { WelcomeComponent } from './welcome/welcome.component';
import { LoginComponent } from './login/login.component';
import { RegistrationComponent } from './registration/registration.component';
import { CartitemsComponent } from './cartitems/cartitems.component';
import { MenuComponent } from './menu/menu.component';
import { ContactUsComponent } from './contact-us/contact-us.component';


const routes: Routes = [
{path: '', component: WelcomeComponent},
{path: 'welcome', component: WelcomeComponent},
// {path: '', component: HeaderComponent},
{path: 'login', component: LoginComponent},
{path: 'registration', component: RegistrationComponent},
{path: 'cartitems', component: CartitemsComponent},
{path: 'menu', component: MenuComponent},
{path: 'contact-us',component:ContactUsComponent}
];
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
